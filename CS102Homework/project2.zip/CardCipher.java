package project2;

/**
 * The CardCipher class is the driver file that will be used for encryption and decryption
 * author: Ricky Jian
 */

public class CardCipher {
	/**
     * The main() method of this program.
     * @param args array of Strings provided on the command line when the program is started;
     * the first string should be the name of the input file containing the input lines
     * it reads the file and handles any exceptions, such as if the file name does not exist
     */
    
	public static void main(String[] args) {
		// TODO Implement method
	}
	
	
}