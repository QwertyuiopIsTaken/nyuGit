package homeworkpack1;

// Class file
public class BinaryFormatException extends RuntimeException {
	public BinaryFormatException(String message) {
		super(message);
	}
}